from AgentBasedModel.states.states import aggToShock, general_states
